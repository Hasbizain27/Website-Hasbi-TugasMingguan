

<?php $__env->startSection('content'); ?>
<h1 class="text-centre">Data Mahasiswa</h1>
    <div class="row">
        
        <button type="button" class="btn btn-success">Tambah</button>
        <table class="table">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama</th>
      <th scope="col">NIM</th>
      <th scope="col">Prodi</th>
        <th scope="col">email</th>
         <th scope="col">nohp</th>
          <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php $i = 1 ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

   
    <tr>
      <th scope="row"><?php echo $i ?></th>
      <td><?php echo e($mahasiswa ["name"]); ?></td>
      <td><?php echo e($mahasiswa ["nim"]); ?></td>
      <td><?php echo e($mahasiswa ["prodi"]); ?></td>
      <td><?php echo e($mahasiswa ["email"]); ?></td>
      <td><?php echo e($mahasiswa ["nohp"]); ?>7</td>
      <td>
      <button type="button" class="btn btn-primary">Edit</button>
      <button type="button" class="btn btn-danger">Hapus</button>
      </td>
      <?php $i++; ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Hasbi_TI\Hasbi-TI24\resources\views/mahasiswa.blade.php ENDPATH**/ ?>