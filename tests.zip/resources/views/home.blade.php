@extends('layouts.main')

@section('content')
<h1>Hallo, selamat datang di halaman home saya!</h1>

@endsection