

<?php $__env->startSection('content'); ?>
<h1 class=text-center>Data Mahasiswa</h1>
<div class="row mt-4">
    <a href ="/tambahmahasiswa">
        <button type="button" class="btn btn-success">Tambah Data</button>
    </a>
    <form action="/logout" method="post" class="d-inline">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-danger">Logout</button>
    </form>
    <br>
    <?php if($message = Session::get('success')): ?>
        
          <script>
            document.addEventListener('DOMContentLoaded', function() {
              Swal.fire({
                  title: "Berhasil!",
                  text: "<?php echo e($message); ?>",
                  icon: "success"
                });
            })
          </script>

        <?php endif; ?>
    <table class="table">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama</th>
      <th scope="col">NIM</th>
      <th scope="col">Prodi</th>
      <th scope="col">Email</th>
      <th scope="col">No. Hp</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php $i= 1 ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo $i ?></th>
      <td><?php echo e($mahasiswa["name"]); ?></td>
      <td><?php echo e($mahasiswa["nim"]); ?></td>
      <td><?php echo e($mahasiswa["prodi"]); ?></td>
      <td><?php echo e($mahasiswa["email"]); ?></td>
      <td><?php echo e($mahasiswa["nohp"]); ?></td>
      <td>
        <a href="tampildata/<?php echo e($mahasiswa['id']); ?>" class="btn btn-primary">Edit</a>
        <a href="#" class="btn btn-danger delete" data-id="<?php echo e($mahasiswa['id']); ?>" 
        data-nama="<?php echo e($mahasiswa['nama']); ?>">Hapus</a>
      </td>
      <?php $i++ ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="https://code.jquery.com/jquery-3.7.1.js" 
    integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" 
    crossorigin="anonymous"></script>

  <script>

    $('.delete').click(function(){

      let id = $(this).attr('data-id');
      let nama = $(this).attr('data-nama');

      Swal.fire({
      title: "Yakin dihapus?",
      text: "Data" +nama+ " akan terhapus!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
      }).then((result) => {
  if (result.isConfirmed) {
      window.location = "/delete/" +id;
    }
  })
});
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Hasbi_TI\Hasbi-TI24\resources\views/Mahasiswa.blade.php ENDPATH**/ ?>